// eslint-disable-next-line import/prefer-default-export
export const GET_ALL_COMMENTS = 'GET_ALL_COMMENTS'
