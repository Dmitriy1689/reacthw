/* eslint-disable import/prefer-default-export */
// Типы для состояния фильтра. Избавляемся от волшебных строк путем присвания констант
export const SET_FILTER = 'SET_FILTER'
