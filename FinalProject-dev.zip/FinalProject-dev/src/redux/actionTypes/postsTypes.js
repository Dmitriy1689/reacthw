// Типы для состояния постов. Избавляемся от волшебных строк путем присвания констант
export const GET_POSTS_FROM_SERVER = 'GET_POSTS_FROM_SERVER'
export const ADD_NEW_POST = 'ADD_NEW_POST'
export const DELETE_POST = 'DELETE_POST'
// export const UPDATE_POST = 'UPDATE_POST'
// export const GET_CURRENT_POST = 'GET_CURRENT_POST'
