const TOKEN = 'token'
export default TOKEN
